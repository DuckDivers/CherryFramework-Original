// jQuery

jQuery(document).ready(function(e) {
    jQuery('.zebra table').addClass('zebra');
	jQuery('.zebra tr:even').css('background','#ccc');
});